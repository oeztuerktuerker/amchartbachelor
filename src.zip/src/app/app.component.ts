import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-project';
  private data:any = [];


  private orgTypes: { orgTyp: string, amount: number }[] =[];



  constructor(private http: HttpClient){}


  getData(){
    const url ='http://localhost:5500/src/data/personTask.json'
    this.http.get(url).subscribe((res)=>{
      this.data = res;
    //  console.log(this.orgTypes.length);
     // this.orgTypes[0] =  { "orgTyp": "hii", "amount": 10 };



   
     if(this.orgTypes.length == 0){
      this.orgTypes[0] =  { "orgTyp": this.data[0].organisationType, "amount": 1 };  
    }

     var k = 1;

      for(let i = 0; i < this.data.length; i++){
        for(let j = 0; j < k; j++){


          //if(this.orgTypes[j] != null)
          if(this.orgTypes[j].orgTyp == this.data[i].organisationType){
            this.orgTypes[j].amount++;
            console.log("iffff");
            k++;
            //k++;

          }
          else {
            this.orgTypes[j] =  { "orgTyp": this.data[i].organisationType, "amount": 1 };  
            k++;
          }


        }
      }


   // this.orgTypes[0] =  { "orgTyp": "hii", "amount": 10 };

   console.log(this.data.organisationType);

    console.log(this.orgTypes);


    


    })
  }


}
